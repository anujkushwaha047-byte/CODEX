# SIH Proposal

This project is Smart Education platform for SIH submission.
