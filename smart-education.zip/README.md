# Smart Education

Interactive platform for all age groups to learn via quizzes.
- Student dashboard for quizzes
- Teacher dashboard for quiz management
- Parent dashboard for child progress
